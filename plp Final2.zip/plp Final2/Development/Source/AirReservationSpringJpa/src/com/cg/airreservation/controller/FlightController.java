package com.cg.airreservation.controller;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cg.airreservation.entities.Bookinginfo;
import com.cg.airreservation.entities.Flightinfo;
import com.cg.airreservation.exception.AirlineException;
import com.cg.airreservation.service.IFlightService;

// TODO Add display message and constants which added on model attribute to interface

@Controller
@Scope("session")
public class FlightController {

	@Autowired
	Flightinfo flight;

	@Autowired
	IFlightService service;

	@Autowired
	Bookinginfo bookingInfoBean;

	String type;
	int numOfSeat;
	String email;

	/**
	 * this method used to navigate to page where admin can add new flight
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/adminPage")
	public String navigateToAddFlight(Model model) {
		try {
			ArrayList<String> airlineList = service.fetchAirlineList();
			model.addAttribute("todayDate", LocalDate.now());
			model.addAttribute("airlineList", airlineList);
		} catch (AirlineException e) {
			model.addAttribute("flag", "admin");
			model.addAttribute("errorMessage", e.getMessage());
			return "errorPage";
		}
		model.addAttribute("adminAddFlight", flight);
		return "adminFlight";
	}

	/**
	 * this method is used to add new flight in flightinfo table
	 * 
	 * @param flightinfo
	 *            is bean object in which flight details are stored
	 * @param departureDate
	 *            is departure date
	 * @param arrivalDate
	 *            is arrival date
	 * @param result
	 * @param model
	 * @return
	 */

	// TODO departure date and arrival date add directly to bean object
	@RequestMapping(value = "/flightAdd")
	public String addFlight(
			@ModelAttribute("adminAddFlight") @Valid Flightinfo flightinfo,
			
			BindingResult result, Model model) {
		if (result.hasErrors()) {
			try {
				ArrayList<String> airlineList = service.fetchAirlineList();
				model.addAttribute("todayDate", LocalDate.now());
				model.addAttribute("airlineList", airlineList);
			} catch (AirlineException e) {
				model.addAttribute("flag", "admin");
				model.addAttribute("errorMessage", e.getMessage());
				return "errorPage";
			}
			model.addAttribute("adminAddFlight", flight);
			return "adminFlight";
		}
		
		flightinfo.setRembussseat(flightinfo.getBussseats());
		flightinfo.setRemecoseat(flightinfo.getEcoseats());
		try {
			ArrayList<String> airlineList = service.fetchAirlineList();
			model.addAttribute("airlineList", airlineList);
		} catch (AirlineException e) {
			model.addAttribute("flag", "admin");
			model.addAttribute("errorMessage", e.getMessage());
			return "errorPage";
		}
		boolean addFlight = false;
		try {
			addFlight = service.addNewFlight(flightinfo);
		} catch (AirlineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (addFlight) {
			model.addAttribute("adminAddFlight", flight);
			model.addAttribute("message", "SuccessFully Added");
		} else {
			model.addAttribute("message", "Flight Not Added.. Please try again");
			model.addAttribute("adminAddFlight", flight);
		}
		return "adminFlight";
	}

	/**
	 * this method used to navigate executive to fetch flight details page
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/executivePage")
	public String navigateToFetchFlight(Model model) {
		model.addAttribute("flightBean", flight);
		return "fetchFlightDetails";
	}

	/**
	 * this method is used to fetch flight details for flight entered by
	 * executive
	 * 
	 * @param flightInfo
	 *            is bean object in which flight number is storedo
	 * @param departureDate
	 *            is departure date entered by executive
	 * @param model
	 * @return
	 */
	@RequestMapping("/fetchFlightDetails")
	public String fetchFlightInfo(
			@ModelAttribute("flightBean") Flightinfo flightInfo,
			 Model model) {
		ArrayList<Flightinfo> list = null;
		try {
			//flightInfo.setDeptdate(doepartureDate);
			list = service.searchFlight(flightInfo);
			model.addAttribute("flightList", list);
		} catch (AirlineException e) {
			model.addAttribute("flag", "executive");
			model.addAttribute("errorMessage", e.getMessage());
			return "errorPage";
		}
		return "fetchFlightDetails";
	}

	/**
	 * this method used to navigate customer to search flight page if customer
	 * select search flight option
	 * 
	 * @param custEmail
	 *            is email for logged in customer
	 * @param model
	 * @return
	 */
	@RequestMapping("/searchFlightPage")
	public String searchFlightHome(@RequestParam("custEmail") String custEmail,
			Model model) {
		
		model.addAttribute("email", custEmail);
		try {
			ArrayList<String> sourceList = service.fetchSourceCity();
			ArrayList<String> destinationList = service.fetchDestinationCity();
			model.addAttribute("destinationList", destinationList);
			model.addAttribute("sourceList", sourceList);
			model.addAttribute("todayDate", LocalDate.now());
		} catch (AirlineException e) {
			
			model.addAttribute("flag", "customer");
			model.addAttribute("errorMessage", e.getMessage());
			return "errorPage";
		}
		email = custEmail;
		model.addAttribute("bookingBean", bookingInfoBean);
		return "searchFlight";
	}

	/**
	 * this method is used to search flight in flightinfo table based on entered
	 * details
	 * 
	 * @param searchBooking
	 *            is booking bean object in which details to search flights are
	 *            stored
	 * @param classType
	 *            is class type entered by user for which user want to serch
	 *            flight
	 * @param model
	 * @return
	 */
	@RequestMapping("/displaySearchFlight")
	public String searchFlight(
			@ModelAttribute("bookingBean") Bookinginfo searchBooking,
			@RequestParam("classType") String classType, Model model) {
		
		model.addAttribute("email", email);
		ArrayList<Flightinfo> searchList = new ArrayList<Flightinfo>();
		try {
			searchList = service.getListOfFlight(searchBooking, classType);
			ArrayList<String> sourceList = service.fetchSourceCity();
			ArrayList<String> destinationList = service.fetchDestinationCity();
			model.addAttribute("destinationList", destinationList);
			model.addAttribute("sourceList", sourceList);
		} catch (AirlineException e) {
			model.addAttribute("flag", "customer");
			model.addAttribute("errorMessage", e.getMessage());
			return "errorPage";
		}
		if (searchList.size() == 0) {
			model.addAttribute("searchMessage",
					"No Flight Exist for route "+searchBooking.getSourcecity()+" to "+searchBooking.getDestcity());
			model.addAttribute("bookingBean", bookingInfoBean);
			return "searchFlight";
		}
		model.addAttribute("todayDate", LocalDate.now());
		model.addAttribute("flightList", searchList);
		model.addAttribute("bookingBean", bookingInfoBean);
		numOfSeat = searchBooking.getPassengernum();
		type = classType;
		return "searchFlight";
	}

	/**
	 * this method is used to fetch flight details based on flight is selected
	 * by user and transfer control to calculate controller
	 * 
	 * @param flightId
	 *            is unique flight id selected by customer from list shown to
	 *            customer
	 * @param redirectAttrs
	 *            is reference to RedirectAttributes which used to pass
	 *            attribute and redirect control from one controller to another
	 * @param model
	 * @return
	 */
	@RequestMapping("/fetchFlightInfo")
	public String fetchFlightInfoById(@RequestParam("id") long flightId,
			RedirectAttributes redirectAttrs, Model model) {
		Flightinfo flightInfo = null;
		try {
			flightInfo = service.fetchFlightDetails(flightId);
		} catch (AirlineException e) {
			// TODO \change printstack
			model.addAttribute("flag", "customer");
			model.addAttribute("errorMessage", e.getMessage());
			return "errorPage";
		}
		redirectAttrs.addFlashAttribute("type", type);
		redirectAttrs.addFlashAttribute("totalSeat", numOfSeat);
		redirectAttrs.addFlashAttribute("flightInfo", flightInfo);
		redirectAttrs.addFlashAttribute("custEmail", email);
		return "redirect:/calculate.obj";
	}

}
