package com.cg.airreservation.exception;

/**
 * <AirLine Reservation System> this class used to create user defined exception
 * extending Exception class
 */
@SuppressWarnings("serial")
public class AirlineException extends Exception {

	String message;

	//Parameterized constructor 
	public AirlineException(String message) {
		this.message = message;
	}

	//method having return type string
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return message;
	}

}
