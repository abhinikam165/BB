package com.cg.airreservation.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.airreservation.dao.ICalculateDao;
import com.cg.airreservation.entities.Flightinfo;
import com.cg.airreservation.exception.AirlineException;

@Service
@Transactional
public class CalculateServiceImpl implements ICalculateService {

	@Autowired
	ICalculateDao calculateDao;

	@Override
	public double calculateFare(Flightinfo flightInfo, String classType,
			int numOfSeats) throws AirlineException {
		// TODO Auto-generated method stub
		return calculateDao.calculateFare(flightInfo, classType, numOfSeats);
	}

}
