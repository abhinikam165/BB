package com.cg.airreservation.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import java.util.List;


/**
 * The persistent class for the CUSTOMERINFO database table.
 * 
 */
@Entity
@Component
@Table(name="CUSTOMERINFO")
@NamedQuery(name="Customerinfo.findAll", query="SELECT c FROM Customerinfo c")
public class Customerinfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=20)
	private String custemail;

	@Column(length=20)
	private String custname;

	@Column(length=15)
	private String custpassword;

	@Column(length=10)
	private String custtype;

	//bi-directional many-to-one association to Bookinginfo
	@OneToMany(mappedBy="customerinfo")
	private List<Bookinginfo> bookinginfos;

	public Customerinfo() {
	}

	public String getCustemail() {
		return this.custemail;
	}

	public void setCustemail(String custemail) {
		this.custemail = custemail;
	}

	public String getCustname() {
		return this.custname;
	}

	public void setCustname(String custname) {
		this.custname = custname;
	}

	public String getCustpassword() {
		return this.custpassword;
	}

	public void setCustpassword(String custpassword) {
		this.custpassword = custpassword;
	}

	public String getCusttype() {
		return this.custtype;
	}

	public void setCusttype(String custtype) {
		this.custtype = custtype;
	}

	public List<Bookinginfo> getBookinginfos() {
		return this.bookinginfos;
	}

	public void setBookinginfos(List<Bookinginfo> bookinginfos) {
		this.bookinginfos = bookinginfos;
	}

	public Bookinginfo addBookinginfo(Bookinginfo bookinginfo) {
		getBookinginfos().add(bookinginfo);
		bookinginfo.setCustomerinfo(this);

		return bookinginfo;
	}

	public Bookinginfo removeBookinginfo(Bookinginfo bookinginfo) {
		getBookinginfos().remove(bookinginfo);
		bookinginfo.setCustomerinfo(null);

		return bookinginfo;
	}

}