package com.cg.airreservation.dao;

/**
 * CalculateDaoImpl is implementation of ICalculateDao Interface,
 *  used to calculate total fare based on number of seats customer wants to book. 
 */
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.airreservation.entities.Flightinfo;
import com.cg.airreservation.exception.AirlineException;
import com.cg.airreservation.utility.Mylogger;

//Creating implementation class which implement ICalculateDao interface
@Repository
public class CalculateDaoImpl implements ICalculateDao {

	Logger logger = Mylogger.getLoggerInstance();
	@PersistenceContext
	EntityManager entityManager;

	/*
	 * this method used to calculate total fare having 3 arguments i.e.
	 * FlightInfo entity object, classType and number of seats and return double
	 * value.
	 */
	@Override
	public double calculateFare(Flightinfo flightInfo, String classType,
			int numOfSeats) throws AirlineException {
		double totalFare = 0.0;
		double tax = 0.12;
		if (classType.equals("Business")) {

			totalFare = (numOfSeats * (flightInfo.getBussfare()))
					+ (numOfSeats * (flightInfo.getBussfare()) * tax);
			logger.info("Business Class fare " +totalFare);
		} else if (classType.equals("Economy")) {
			totalFare = (numOfSeats * (flightInfo.getEcofare()))
					+ (numOfSeats * (flightInfo.getEcofare()) * tax);
			logger.info("Economy class fare " +totalFare);
		}
		return totalFare;
	}

}
