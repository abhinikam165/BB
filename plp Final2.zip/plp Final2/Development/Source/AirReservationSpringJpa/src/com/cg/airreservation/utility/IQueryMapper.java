package com.cg.airreservation.utility;

public interface IQueryMapper 
{
	/*Query in FlightDaoImpl*/
	String fetchAirportInfo = "SELECT air.airlinename FROM Airportinfo air";
	String searchFlightbyNumberandDate ="SELECT flight FROM Flightinfo flight WHERE flightnum=:flightNum and deptdate=:date";
	String listFlightByBusiness = "SELECT flight FROM Flightinfo flight WHERE deptdate=:date AND sourcecity=:source AND destinationcity=:destination AND rembussseat>:seats";
	String listFlightByEconomy = "SELECT flight FROM Flightinfo flight WHERE deptdate=:date AND sourcecity=:source AND destinationcity=:destination AND remecoseat>:seats";
	String distinctSourceCity = "SELECT DISTINCT f.sourcecity FROM Flightinfo f";
	String distinctDestinationCity = "SELECT DISTINCT f.destinationcity FROM Flightinfo f";
	String updateBusinessSeatsAfterBooking = "UPDATE Flightinfo flightInfo SET rembussseat=rembussseat-:bookSeat WHERE flightid=:flightId";
	String updateEconomySeatsAfterBooking = "UPDATE Flightinfo flightInfo SET remecoseat=remecoseat-:bookSeat WHERE flightid=:flightId";
	String updateBusinessSeatsAfterCancel = "UPDATE Flightinfo flightInfo SET rembussseat=rembussseat+:bookSeat WHERE flightid=:flightId";
	String updateEconomySeatsAfterCancel = "UPDATE Flightinfo flightInfo SET remecoseat=remecoseat+:bookSeat WHERE flightid=:flightId";
	String updateBusinessSeatsWhileModify = "UPDATE Flightinfo flightInfo SET rembussseat=rembussseat+:oldBookSeat-:newBookSeat WHERE flightid=:flightId";
	String updateEconomySeatsWhileModify = "UPDATE Flightinfo flightInfo SET remecoseat=remecoseat+:oldBookSeat-:newBookSeat WHERE flightid=:flightId";
	//customer cancels economy seats and then books business seats
	String updateBusinessSeat = "UPDATE Flightinfo flightInfo SET rembussseat=rembussseat-:newBookSeat,remecoseat=remecoseat+:oldBookSeat WHERE flightid=:flightId";
	//customer cancels business seats and then books economy seats
	String updateEconomySeat = "UPDATE Flightinfo flightInfo SET remecoseat=remecoseat-:newBookSeat,rembussseat=rembussseat+:oldBookSeat WHERE flightid=:flightId";
	
	/*Query in BookingDaoImpl*/
	String bookingDetails = "select book FROM Bookinginfo book where customerinfo.custemail=:email AND dateofjourney>:date";
}
