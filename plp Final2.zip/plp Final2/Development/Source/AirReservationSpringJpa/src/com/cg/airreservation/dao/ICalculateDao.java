package com.cg.airreservation.dao;

import com.cg.airreservation.entities.Flightinfo;
import com.cg.airreservation.exception.AirlineException;

public interface ICalculateDao {

	public double calculateFare(Flightinfo flightInfo,String classType,int numOfSeats) throws AirlineException;
}
