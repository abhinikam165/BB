package com.cg.airreservation.service;

import com.cg.airreservation.entities.Customerinfo;
import com.cg.airreservation.exception.AirlineException;

public interface ILoginService {

	public Customerinfo validateCredentials(Customerinfo bean) throws AirlineException;
	
}
