package com.cg.airreservation.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.airreservation.entities.Customerinfo;
import com.cg.airreservation.exception.AirlineException;
import com.cg.airreservation.utility.Mylogger;

@Repository
public class LoginDaoImpl implements ILoginDao {

	Logger logger = Mylogger.getLoggerInstance();

	@PersistenceContext
	EntityManager entityManager;

	// retrieving credentials for validation purpose by email
	@Override
	public Customerinfo validateCredentials(Customerinfo bean)
			throws AirlineException {
		Customerinfo details = entityManager.find(Customerinfo.class,
				bean.getCustemail());

		
		if (details == null) {
			logger.error("login credentials are invalid" );

			throw new AirlineException("User not found");
		}

		else
			logger.info("login successful for user " +details.getCustname());

		return details;
	}

}
