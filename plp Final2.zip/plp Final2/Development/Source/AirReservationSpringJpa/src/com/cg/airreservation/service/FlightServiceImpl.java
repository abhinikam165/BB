package com.cg.airreservation.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.airreservation.dao.IFlightDao;
import com.cg.airreservation.entities.Bookinginfo;
import com.cg.airreservation.entities.Flightinfo;
import com.cg.airreservation.exception.AirlineException;

@Service
@Transactional
public class FlightServiceImpl implements IFlightService {
	
	@Autowired
	IFlightDao dao;
	
	@Override
	public ArrayList<Flightinfo> searchFlight(Flightinfo flight) throws AirlineException {
		// TODO Auto-generated method stub
		return dao.searchFlight(flight);
	}
	

	@Override
	public boolean addNewFlight(Flightinfo flightinfo) throws AirlineException {
		// TODO Auto-generated method stub
		return dao.addNewFlight(flightinfo);
	}


	@Override
	public ArrayList<Flightinfo> getListOfFlight(Bookinginfo bookingInfo,
			String classType) throws AirlineException {
		// TODO Auto-generated method stub
		return dao.getListOfFlight(bookingInfo, classType);
	}


	@Override
	public Flightinfo fetchFlightDetails(long id) throws AirlineException {
		// TODO Auto-generated method stub
		return dao.fetchFlightDetails(id);
	}


	@Override
	public ArrayList<String> fetchSourceCity() throws AirlineException {
		// TODO Auto-generated method stub
		return dao.fetchSourceCity();
	}


	@Override
	public int updateFlightSeats(Bookinginfo bookingDetail)
			throws AirlineException {
		// TODO Auto-g-enerated method stub
		return dao.updateFlightSeats(bookingDetail);
	}


	@Override
	public int modifyFlightAfterCancel(Bookinginfo bookingDetail)
			throws AirlineException {
		// TODO Auto-generated method stub
		return dao.modifyFlightAfterCancel(bookingDetail);
	}


	@Override
	public int modifyFlightAfterUpdate(Bookinginfo newBookingDetail,
			Bookinginfo oldBookingDetail) throws AirlineException {
		// TODO Auto-generated method stub
		return dao.modifyFlightAfterUpdate(newBookingDetail, oldBookingDetail);
	}


	@Override
	public ArrayList<String> fetchAirlineList() throws AirlineException {
		// TODO Auto-generated method stub
		return dao.fetchAirlineList();
	}


	@Override
	public ArrayList<String> fetchDestinationCity() throws AirlineException {
		// TODO Auto-generated method stub
		return dao.fetchDestinationCity();
	}

}
