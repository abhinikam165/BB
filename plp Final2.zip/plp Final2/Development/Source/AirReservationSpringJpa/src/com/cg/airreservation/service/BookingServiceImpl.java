package com.cg.airreservation.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.airreservation.dao.IBookingDao;
import com.cg.airreservation.entities.Bookinginfo;
import com.cg.airreservation.exception.AirlineException;

@Service
@Transactional
public class BookingServiceImpl implements IBookingService {

	@Autowired
	IBookingDao bookingDao;

	@Override
	public boolean confirmBooking(Bookinginfo bookingInfo)
			throws AirlineException {
		// TODO Auto-generated method stub
		return bookingDao.confirmBooking(bookingInfo);
	}

	@Override
	public boolean updateBooking(Bookinginfo bookingInfo)
			throws AirlineException {
		// TODO Auto-generated method stub
		return bookingDao.updateBooking(bookingInfo);
	}

	@Override
	public boolean cancelBooking(long id) throws AirlineException {
		// TODO Auto-generated method stub
		return bookingDao.cancelBooking(id);
	}

	@Override
	public Bookinginfo fetchBookingDetails(long id) throws AirlineException {
		// TODO Auto-generated method stub
		return bookingDao.fetchBookingDetails(id);
	}

	@Override
	public ArrayList<Bookinginfo> getBookingDetails(String email) throws AirlineException {
		// TODO Auto-generated method stub
		return bookingDao.getBookingDetails(email);
	}

	@Override
	public ArrayList<Bookinginfo> getAllBookingDetails(String email)
			throws AirlineException {
		// TODO Auto-generated method stub
		return bookingDao.getAllBookingDetails(email);
	}

}
