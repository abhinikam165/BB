package com.cg.airreservation.entities;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import java.util.List;


/**
 * The persistent class for the AIRPORTINFO database table.
 * 
 */
@Component
@Entity
@Table(name="AIRPORTINFO")
@NamedQuery(name="Airportinfo.findAll", query="SELECT a FROM Airportinfo a")
public class Airportinfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=40)
	private String airlinename;

	@Column(length=10)
	private String airportabbrev;

	@Column(length=16)
	private String airportlocation;

	//bi-directional many-to-one association to Flightinfo
	@OneToMany(mappedBy="airportinfo")
	private List<Flightinfo> flightinfos;

	public Airportinfo() {
	}

	public String getAirlinename() {
		return this.airlinename;
	}

	public void setAirlinename(String airlinename) {
		this.airlinename = airlinename;
	}

	public String getAirportabbrev() {
		return this.airportabbrev;
	}

	public void setAirportabbrev(String airportabbrev) {
		this.airportabbrev = airportabbrev;
	}

	public String getAirportlocation() {
		return this.airportlocation;
	}

	public void setAirportlocation(String airportlocation) {
		this.airportlocation = airportlocation;
	}

	public List<Flightinfo> getFlightinfos() {
		return this.flightinfos;
	}

	public void setFlightinfos(List<Flightinfo> flightinfos) {
		this.flightinfos = flightinfos;
	}

	public Flightinfo addFlightinfo(Flightinfo flightinfo) {
		getFlightinfos().add(flightinfo);
		flightinfo.setAirportinfo(this);

		return flightinfo;
	}

	public Flightinfo removeFlightinfo(Flightinfo flightinfo) {
		getFlightinfos().remove(flightinfo);
		flightinfo.setAirportinfo(null);

		return flightinfo;
	}

}