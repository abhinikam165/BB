package com.cg.airreservation.service;

import com.cg.airreservation.entities.Flightinfo;
import com.cg.airreservation.exception.AirlineException;

public interface ICalculateService {

	public double calculateFare(Flightinfo flightInfo,String classType,int numOfSeats) throws AirlineException;
	
}
